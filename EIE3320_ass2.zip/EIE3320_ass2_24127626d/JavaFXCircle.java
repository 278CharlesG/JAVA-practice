// Student Name: Ge Yunjie
// StudentID: 24127626D
import javafx.scene.layout.Pane;
import javafx.scene.shape.Circle;

/**
 * JavaFXCircle represents a circle shape that can be drawn on a JavaFX Pane.
 * It extends the abstract Shape class and implements all the abstract methods:
 * it computes its own area and perimeter, prints its information to the
 * console, and renders itself onto the canvas as a JavaFX Circle node.
 */
public class JavaFXCircle extends Shape {
    private float radius;

    public JavaFXCircle() {
        // Initialize default field value
        this.radius = 50.0f;
        computeArea();
        computePerimeter();
    }

    public JavaFXCircle(float r) {
        // Initialize constructor parameter with parent context metrics
        this.radius = r;
        computeArea();
        computePerimeter();
    }

    @Override
    public void readShape() {
        // Default initialized radius 
        this.radius = 50.0f;
    }

    @Override
    public void computeArea() {
        // Implement mathematical formula for circle area calculation if needed
        this.area = (float) (Math.PI * radius * radius);
    }

    @Override
    public void computePerimeter() {
        // Implement mathematical formula for circle perimeter calculation if needed
        this.perimeter = (float) (2 * Math.PI * radius);
    }

    @Override
    public void displayShape() {
        // Print the calculated area and perimeter results to the console window
        System.out.println("Circle Created - Radius: " + radius + ", Area: " + area + ", Perimeter: " + perimeter);
    }

    @Override
    public void draw(Pane canvasPane) {
        Circle circle = new Circle(this.x + this.radius, this.y + this.radius, this.radius);
        circle.setFill(this.shapeColor);
        canvasPane.getChildren().add(circle);
    }
}
