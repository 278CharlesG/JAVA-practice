// Student name: Ge Yunjie
// StudentID: 24127626D
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

/**
 * JavaFXMainApp is the main entry point of the JavaFX GUI application.
 * It builds a window with a control panel on the left (six buttons) and a
 * white drawing canvas on the right. Every button is connected to an event
 * handler, so the user can add a circle, clear the screen, switch the
 * circle's colour between red and blue, and move the circle up or down by
 * 15 pixels per click.
 */
public class JavaFXMainApp extends Application {

    private Pane canvasPane;    
    private Shape activeCircle = null;

    @Override
    public void start(Stage primaryStage) {
        
        
        BorderPane root = new BorderPane();

        VBox controlPanel = new VBox(10);
        controlPanel.setPadding(new Insets(15));
        controlPanel.setStyle("-fx-background-color: #f4f4f4;");
        controlPanel.setAlignment(Pos.TOP_CENTER);
        controlPanel.setPrefWidth(150);

        
        Button btnAddCircle = new Button("Add Circle");
        Button btnClearScreen = new Button("Clear Screen");
        Button btnColorRed = new Button("Color: Red");
        Button btnColorBlue = new Button("Color: Blue");
        Button btnMoveUp = new Button("Move Up");
        Button btnMoveDown = new Button("Move Down");

        
        Button[] buttons = {btnAddCircle, btnClearScreen, btnColorRed, btnColorBlue, btnMoveUp, btnMoveDown};
        for (Button btn : buttons) {
            btn.setMaxWidth(Double.MAX_VALUE);
        }

        controlPanel.getChildren().addAll(btnAddCircle, btnClearScreen, btnColorRed, btnColorBlue, btnMoveUp, btnMoveDown);

        
        canvasPane = new Pane();
        canvasPane.setStyle("-fx-background-color: white;");

        root.setLeft(controlPanel);
        root.setCenter(canvasPane);

        //add circle: remove the previous circle, create a new green one,
        // run the full shape life-cycle and draw it onto the canvas
        btnAddCircle.setOnAction(e -> {
            canvasPane.getChildren().clear();
            
            JavaFXCircle circle = new JavaFXCircle(50);
            circle.readShape();
            circle.computeArea();
            circle.computePerimeter();
            circle.displayShape();
            
            activeCircle = circle;
            activeCircle.draw(canvasPane);
        });

        // Clear Screen: remove all shapes and reset the active shape reference
        btnClearScreen.setOnAction(e -> {
            canvasPane.getChildren().clear();
            activeCircle = null;
        });

        // Color_red:change the active circle to red and refresh the canvas
        btnColorRed.setOnAction(e -> {
            if (activeCircle != null) {
                activeCircle.setColor(Color.RED);
                refreshCanvas();
            }
        });

        // Color_blue:change the active circle to blue and refresh the canvas
        btnColorBlue.setOnAction(e -> {
            if (activeCircle != null) {
                activeCircle.setColor(Color.BLUE);
                refreshCanvas();
            }
        });

        //moveup:shift the active circle 15 pixels up and refresh
        btnMoveUp.setOnAction(e -> {
            if (activeCircle != null) {
                activeCircle.moveUp();
                refreshCanvas();
            }
        });

        //movedown:shift the active circle 15 pixels down and refresh
        btnMoveDown.setOnAction(e -> {
            if (activeCircle != null) {
                activeCircle.moveDown();
                refreshCanvas();
            }
        });

        Scene scene = new Scene(root, 600, 300);
        primaryStage.setTitle("EIE3320 A2 JavaFX Homework");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    // Redraw the active circle after its colour or position has changed.
    // If no circle exists yet, the canvas simply stays empty.
    private void refreshCanvas() {
        canvasPane.getChildren().clear();
        if (activeCircle != null) {
            activeCircle.draw(canvasPane);
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}
