// Student Name: Ge Yunjie
// StudentID: 24127626D
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;

/**
 * Shape is the abstract base class of all drawable shapes. It stores the
 * common state of a shape (area, perimeter, position and colour) and
 * declares the abstract methods that every concrete shape must implement.
 * The concrete subclass JavaFXCircle inherits the colour and movement
 * behaviour provided by this class.
 */
public abstract class Shape implements Drawable {
    protected float area;
    protected float perimeter;
    
    // New fields to support coordinates and dynamic styling
    protected double x = 50;
    protected double y = 50;
    protected Color shapeColor = Color.GREEN; 
    
    public abstract void readShape();               
    public abstract void computeArea();
    public abstract void computePerimeter();  
    public abstract void displayShape();
    
    // Setters to allow the UI controls to interact with the object state
    public void setColor(Color color) {
        this.shapeColor = color;
    }
    
    public void moveUp() {
        this.y -= 15;
    }
    
    public void moveDown() {
        this.y += 15;
    }
}
