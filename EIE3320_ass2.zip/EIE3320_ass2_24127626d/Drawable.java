// Student Name: Ge Yunjie
// StudentID: 24127626D
import javafx.scene.layout.Pane;

/**
 * Drawable is the common interface for every shape that can be rendered
 * onto the JavaFX drawing canvas. Any class that implements this interface
 * must provide its own draw() implementation that adds the shape to the
 * given Pane container.
 */
public interface Drawable {
    // Upgraded to use JavaFX's layout container
    void draw(Pane canvasPane);
}
